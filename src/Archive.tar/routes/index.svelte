
<script>
  import Home from '../components/Home.svelte'
</script>

<Home/>

