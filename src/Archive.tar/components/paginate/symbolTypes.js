export const PREVIOUS_PAGE = 'PREVIOUS_PAGE'
export const NEXT_PAGE = 'NEXT_PAGE'
export const ELLIPSIS = 'ELLIPSIS'